﻿using UnityEngine;
using System.Collections;

// change/add/remove entries for your project

public enum MappedAxis
{
	Horizontal,
	Vertical,
	Axis3,
	Axis4
}
