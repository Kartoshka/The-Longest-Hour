using UnityEngine;
using System.Collections;

public enum GamepadTrigger
{
	Left,
	Right
}
