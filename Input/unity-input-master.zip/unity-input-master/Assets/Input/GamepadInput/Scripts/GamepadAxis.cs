using UnityEngine;
using System.Collections;

public enum GamepadAxis
{
	LeftStickX,
	LeftStickY,
	RightStickX,
	RightStickY,
	LeftTrigger,
	RightTrigger
}
