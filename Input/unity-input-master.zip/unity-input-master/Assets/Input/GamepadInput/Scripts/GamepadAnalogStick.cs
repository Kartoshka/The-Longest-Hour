using UnityEngine;
using System.Collections;

public enum GamepadAnalogStick
{
	Left,
	Right
}